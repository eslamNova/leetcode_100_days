import React from 'react';
import { X, Check } from 'lucide-react';

interface DayModalProps {
  day: number;
  title: string;
  content: string;
  onClose: () => void;
  isRead: boolean;
  onMarkAsRead: () => void;
}

function DayModal({ day, title, content, onClose, isRead, onMarkAsRead }: DayModalProps) {
  return (
    <div className="modal-overlay fixed inset-0 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div 
        className="bg-white rounded-lg w-full max-w-lg max-h-[80vh] shadow-xl transform transition-all flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex justify-between items-center p-6 border-b">
          <h2 className="text-2xl font-bold text-primary">اليوم {day}</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-accent transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
        
        <div className="p-6 overflow-y-auto flex-grow">
          <h3 className="text-xl font-bold text-accent mb-4">{title}</h3>
          <p className="text-lg text-gray-700 leading-relaxed whitespace-pre-wrap">{content}</p>
        </div>

        <div className="border-t p-4 flex justify-end">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onMarkAsRead();
            }}
            className={`flex items-center px-4 py-2 rounded-lg transition-colors ${
              isRead 
                ? 'bg-green-100 text-green-700 hover:bg-green-200' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <Check className="w-5 h-5 ml-2" />
            {isRead ? 'تم القراءة' : 'تحديد كمقروء'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default DayModal;