import React, { useState, useEffect, lazy, Suspense } from 'react';
import { Moon, Github, MessageCircle } from 'lucide-react';
import ramadanData from './data.json';

const DayModal = lazy(() => import('./components/DayModal'));

interface DayData {
  title: string;
  content: string;
}

function App() {
  const [selectedDay, setSelectedDay] = useState<number | null>(null);
  const [dayData, setDayData] = useState<DayData | null>(null);
  const [readDays, setReadDays] = useState<number[]>([]);

  useEffect(() => {
    if (selectedDay) {
      setDayData(ramadanData.days[selectedDay as keyof typeof ramadanData.days]);
    }
  }, [selectedDay]);

  useEffect(() => {
    // Load read days from localStorage
    const savedReadDays = localStorage.getItem('readDays');
    if (savedReadDays) {
      setReadDays(JSON.parse(savedReadDays));
    }
  }, []);

  const handleDayClick = (day: number) => {
    setSelectedDay(day);
  };

  const closeModal = () => {
    setSelectedDay(null);
    setDayData(null);
  };

  const handleMarkAsRead = (day: number) => {
    const newReadDays = readDays.includes(day) 
      ? readDays.filter(d => d !== day) 
      : [...readDays, day];
    
    setReadDays(newReadDays);
    localStorage.setItem('readDays', JSON.stringify(newReadDays));
  };

  return (
    <div className="min-h-screen">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <header className="text-center mb-12">
          <div className="w-40 h-40 mx-auto bg-white rounded-full shadow-lg flex items-center justify-center mb-6 floating">
            <Moon className="w-20 h-20 text-primary" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">دروس الشيخ ماجد</h1>
          <p className="text-lg text-accent mb-2">مسجد الهدى - رمضان 1446</p>
          <a
            href="https://t.me/engafr"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center text-primary hover:text-accent transition-colors"
          >
            <MessageCircle className="w-5 h-5 ml-2" />
            قناة الشيخ ماجد على تليجرام
          </a>
        </header>

        {/* Calendar Grid */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-12">
          {Array.from({ length: 30 }, (_, i) => i + 1).map((day) => (
            <div
              key={day}
              className={`day-cell ${selectedDay === day ? 'active' : ''} ${
                readDays.includes(day) ? 'bg-green-100 hover:bg-green-200' : ''
              }`}
              onClick={() => handleDayClick(day)}
            >
              <div className="text-center">
                <span className="text-2xl font-bold text-primary">{day}</span>
                <h3 className="text-sm text-accent mt-2">
                  {ramadanData.days[day as keyof typeof ramadanData.days].title}
                </h3>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <footer className="text-center text-primary mt-8">
          <p className="text-lg text-accent mb-2">تم تدوين هذه النصوص مباشرةً أثناء الدروس وقمت بنشرها سريعًا قبل التدقيق وإكمال ما نقص للمراجعة السريعة قبل الامتحان، على أن يتم العمل على هذا الأمر بشكل محكم إن شاء الله، ولذا قد تجد بعض الأخطاء الإملائية أو الجمل غير المكتملة، ولا بأس فكان الهدف هو الإلمام بجل كلام الشيخ ماجد ومحاولة تحرير أهم النقاط قدر المستطاع. ولمن يرغب في المساهمة بالتدقيق و التنسيق فيما بعد إن شاء الله، يمكنه التواصل معي عبر واتساب  <a href="https://wa.me/201010698334" className="text-blue-500 underline">01010698334</a>.</p>

          
          {/* <a
            href="https://github.com/eslamNova"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center text-accent hover:text-primary transition-colors"
          >
            <Github className="w-5 h-5 ml-2" />
            GitHub
          </a> */}
        </footer>
      </div>

      {/* Day Modal */}
      {selectedDay && dayData && (
        <Suspense fallback={<div className="modal-overlay fixed inset-0 flex items-center justify-center">جاري التحميل...</div>}>
          <DayModal
            day={selectedDay}
            title={dayData.title}
            content={dayData.content}
            onClose={closeModal}
            isRead={readDays.includes(selectedDay)}
            onMarkAsRead={() => handleMarkAsRead(selectedDay)}
          />
        </Suspense>
      )}
    </div>
  );
}

export default App;