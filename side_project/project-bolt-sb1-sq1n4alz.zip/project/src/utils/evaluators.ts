import { Question } from '../data/questions';

interface EvaluationResult {
  correct: boolean;
  feedback: string;
}

export function evaluateAnswer(content: string, question: Question): EvaluationResult {
  const doc = new DOMParser().parseFromString(content, 'text/html');
  
  switch (question.id) {
    case 1: // Bold and centered title
      const hasBold = doc.querySelector('b, strong') !== null;
      const hasCentered = content.includes('text-align: center') || content.includes('justifyCenter');
      return {
        correct: hasBold && hasCentered,
        feedback: hasBold && hasCentered 
          ? "Perfect! You've correctly formatted the title."
          : `Missing: ${!hasBold ? 'bold text' : ''} ${!hasCentered ? 'center alignment' : ''}`
      };

    case 2: // Image insertion and alignment
      const hasImage = doc.querySelector('img') !== null;
      const isImageCentered = content.includes('text-align: center') || 
                             content.includes('justifyCenter') ||
                             doc.querySelector('img[style*="margin: auto"]') !== null;
      return {
        correct: hasImage && isImageCentered,
        feedback: hasImage && isImageCentered
          ? "Great! Image inserted and centered correctly."
          : `Missing: ${!hasImage ? 'image' : ''} ${!isImageCentered ? 'center alignment' : ''}`
      };

    case 3: // Table with formatting
      const hasTable = doc.querySelector('table') !== null;
      const hasTableHeaders = doc.querySelector('th, td strong, td b') !== null;
      return {
        correct: hasTable && hasTableHeaders,
        feedback: hasTable && hasTableHeaders
          ? "Excellent! Table created with proper formatting."
          : `Missing: ${!hasTable ? 'table' : ''} ${!hasTableHeaders ? 'bold headers' : ''}`
      };

    case 4: // Lists
      const hasList = doc.querySelector('ul, ol') !== null;
      const hasThreeItems = doc.querySelectorAll('li').length >= 3;
      return {
        correct: hasList && hasThreeItems,
        feedback: hasList && hasThreeItems
          ? "Well done! List created with correct number of items."
          : `Missing: ${!hasList ? 'list' : ''} ${!hasThreeItems ? 'three items' : ''}`
      };

    default:
      return {
        correct: false,
        feedback: "Unable to evaluate this question type."
      };
  }
}