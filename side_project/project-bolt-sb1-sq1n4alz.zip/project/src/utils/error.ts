export function getErrorMessage(error: unknown): string {
  if (error instanceof Error) {
    // Handle Supabase auth errors which often have a message property
    if ('message' in error) {
      const message = error.message.toLowerCase();
      
      // Map common Supabase error messages to user-friendly messages
      if (message.includes('invalid login credentials')) {
        return 'Invalid email or password';
      }
      if (message.includes('email already registered')) {
        return 'This email is already registered';
      }
      if (message.includes('invalid email')) {
        return 'Please enter a valid email address';
      }
      
      return error.message;
    }
    return error.toString();
  }
  
  if (typeof error === 'string') {
    return error;
  }
  
  return 'An unexpected error occurred';
}