import React from 'react';
import { AlertCircle } from 'lucide-react';

interface ErrorMessageProps {
  message: string;
}

export function ErrorMessage({ message }: ErrorMessageProps) {
  return (
    <div className="bg-red-50 text-red-500 p-3 rounded flex items-center gap-2">
      <AlertCircle className="w-5 h-5" />
      <span>{message}</span>
    </div>
  );
}