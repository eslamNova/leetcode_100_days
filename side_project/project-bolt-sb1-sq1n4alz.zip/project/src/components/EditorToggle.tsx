import React from 'react';
import { FileText, Table2 } from 'lucide-react';

interface EditorToggleProps {
  activeEditor: 'word' | 'excel';
  onToggle: (editor: 'word' | 'excel') => void;
}

export function EditorToggle({ activeEditor, onToggle }: EditorToggleProps) {
  return (
    <div className="flex gap-2 mb-4">
      <button
        onClick={() => onToggle('word')}
        className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors
          ${activeEditor === 'word'
            ? 'bg-blue-600 text-white'
            : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
          }`}
      >
        <FileText className="w-5 h-5" />
        <span>Word</span>
      </button>
      <button
        onClick={() => onToggle('excel')}
        className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors
          ${activeEditor === 'excel'
            ? 'bg-green-600 text-white'
            : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
          }`}
      >
        <Table2 className="w-5 h-5" />
        <span>Excel</span>
      </button>
    </div>
  );
}