import React, { useState } from 'react';
import { Table } from 'lucide-react';

interface TableInsertProps {
  onInsert: (rows: number, cols: number) => void;
}

export function TableInsert({ onInsert }: TableInsertProps) {
  const [showGrid, setShowGrid] = useState(false);
  const [hoveredCells, setHoveredCells] = useState({ rows: 0, cols: 0 });
  const maxRows = 8;
  const maxCols = 8;

  const handleMouseEnter = (row: number, col: number) => {
    setHoveredCells({ rows: row + 1, cols: col + 1 });
  };

  return (
    <div className="relative">
      <button
        className="flex items-center gap-2 px-3 py-1 text-sm rounded hover:bg-gray-100"
        onMouseEnter={() => setShowGrid(true)}
        onMouseLeave={() => !showGrid && setHoveredCells({ rows: 0, cols: 0 })}
      >
        <Table className="w-4 h-4" />
        <span>Table</span>
      </button>

      {showGrid && (
        <div
          className="absolute top-full left-0 mt-2 bg-white shadow-lg rounded-lg p-2 z-50"
          onMouseLeave={() => setShowGrid(false)}
        >
          <div className="grid grid-cols-8 gap-1 p-2">
            {Array.from({ length: maxRows }).map((_, rowIndex) => (
              <React.Fragment key={rowIndex}>
                {Array.from({ length: maxCols }).map((_, colIndex) => (
                  <div
                    key={`${rowIndex}-${colIndex}`}
                    className={`w-6 h-6 border ${
                      rowIndex < hoveredCells.rows && colIndex < hoveredCells.cols
                        ? 'bg-blue-200 border-blue-400'
                        : 'border-gray-300'
                    }`}
                    onMouseEnter={() => handleMouseEnter(rowIndex, colIndex)}
                    onClick={() => {
                      onInsert(hoveredCells.rows, hoveredCells.cols);
                      setShowGrid(false);
                    }}
                  />
                ))}
              </React.Fragment>
            ))}
          </div>
          <div className="text-center text-sm text-gray-600 mt-2">
            {hoveredCells.rows}×{hoveredCells.cols} Table
          </div>
        </div>
      )}
    </div>
  );
}