import { useRef, useState, useEffect } from 'react';

export function useEditor(onAnswer: (content: string) => void) {
  const [zoom, setZoom] = useState(100);
  const [layout, setLayout] = useState('print');
  const editorRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (editorRef.current) {
      editorRef.current.contentEditable = 'true';
    }
  }, []);

  const handleFormat = (command: string) => {
    document.execCommand(command, false);
    if (editorRef.current) {
      onAnswer(editorRef.current.innerHTML);
    }
  };

  const insertTable = (rows: number, cols: number) => {
    if (!editorRef.current) return;

    const table = document.createElement('table');
    table.style.width = '100%';
    table.style.borderCollapse = 'collapse';
    table.style.marginBottom = '1rem';

    for (let i = 0; i < rows; i++) {
      const row = table.insertRow();
      for (let j = 0; j < cols; j++) {
        const cell = row.insertCell();
        cell.style.border = '1px solid #ccc';
        cell.style.padding = '8px';
        if (i === 0) {
          cell.style.backgroundColor = '#f3f4f6';
          cell.style.fontWeight = 'bold';
        }
      }
    }

    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      range.deleteContents();
      range.insertNode(table);
      selection.collapseToEnd();
    } else {
      editorRef.current.appendChild(table);
    }

    onAnswer(editorRef.current.innerHTML);
  };

  const handleZoom = (direction: 'in' | 'out') => {
    const newZoom = direction === 'in' ? zoom + 10 : zoom - 10;
    const clampedZoom = Math.max(50, Math.min(200, newZoom));
    setZoom(clampedZoom);
    if (editorRef.current) {
      editorRef.current.style.transform = `scale(${clampedZoom / 100})`;
    }
  };

  return {
    editorRef,
    zoom,
    layout,
    setLayout,
    handleFormat,
    handleZoom,
    insertTable
  };
}