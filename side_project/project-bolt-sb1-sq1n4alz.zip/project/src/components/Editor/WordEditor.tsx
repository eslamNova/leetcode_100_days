import React, { useState } from 'react';
import { HomeTab } from '../Ribbon/HomeTab';
import { InsertTab } from '../Ribbon/InsertTab';
import { FileTab } from '../Ribbon/FileTab';
import { ViewTab } from '../Ribbon/ViewTab';
import { LayoutTab } from '../Ribbon/LayoutTab';
import { RibbonTab } from '../Ribbon/RibbonTab';
import { saveDocument, exportToPDF, openDocument } from '../../utils/fileOperations';
import { useEditor } from './useEditor';

interface WordEditorProps {
  onAnswer: (answer: string) => void;
}

export function WordEditor({ onAnswer }: WordEditorProps) {
  const [activeTab, setActiveTab] = useState('home');
  const {
    editorRef,
    zoom,
    layout,
    setLayout,
    handleFormat,
    handleZoom,
    insertTable
  } = useEditor(onAnswer);

  return (
    <div className="bg-white rounded-lg shadow-lg">
      <div className="border-b border-gray-200">
        <div className="flex border-b border-gray-200">
          <RibbonTab
            label="File"
            isActive={activeTab === 'file'}
            onClick={() => setActiveTab('file')}
          />
          <RibbonTab
            label="Home"
            isActive={activeTab === 'home'}
            onClick={() => setActiveTab('home')}
          />
          <RibbonTab
            label="Insert"
            isActive={activeTab === 'insert'}
            onClick={() => setActiveTab('insert')}
          />
          <RibbonTab
            label="Layout"
            isActive={activeTab === 'layout'}
            onClick={() => setActiveTab('layout')}
          />
          <RibbonTab
            label="View"
            isActive={activeTab === 'view'}
            onClick={() => setActiveTab('view')}
          />
        </div>
        
        {activeTab === 'file' && (
          <FileTab
            onSave={() => {
              if (editorRef.current) {
                saveDocument(editorRef.current.innerHTML);
              }
            }}
            onOpen={() => {
              openDocument((content) => {
                if (editorRef.current) {
                  editorRef.current.innerHTML = content;
                  onAnswer(content);
                }
              });
            }}
            onExport={() => {
              if (editorRef.current) {
                exportToPDF(editorRef.current.innerHTML);
              }
            }}
            onPrint={() => window.print()}
          />
        )}
        {activeTab === 'home' && (
          <HomeTab onFormatClick={handleFormat} />
        )}
        {activeTab === 'insert' && (
          <InsertTab
            onInsertImage={() => {
              const input = document.createElement('input');
              input.type = 'file';
              input.accept = 'image/*';
              input.onchange = (e) => {
                const file = (e.target as HTMLInputElement).files?.[0];
                if (file) {
                  const reader = new FileReader();
                  reader.onload = (e) => {
                    const img = document.createElement('img');
                    img.src = e.target?.result as string;
                    img.style.maxWidth = '100%';
                    editorRef.current?.appendChild(img);
                    onAnswer(editorRef.current?.innerHTML || '');
                  };
                  reader.readAsDataURL(file);
                }
              };
              input.click();
            }}
            onInsertTable={insertTable}
            onInsertLink={() => {
              const url = prompt('Enter URL:');
              if (url) document.execCommand('createLink', false, url);
            }}
          />
        )}
        {activeTab === 'layout' && (
          <LayoutTab onFormat={handleFormat} />
        )}
        {activeTab === 'view' && (
          <ViewTab
            onZoomIn={() => handleZoom('in')}
            onZoomOut={() => handleZoom('out')}
            onLayoutChange={setLayout}
          />
        )}
      </div>

      <div
        ref={editorRef}
        className={`min-h-[500px] p-8 focus:outline-none transition-transform duration-200
          ${layout === 'print' ? 'max-w-[8.5in] mx-auto shadow-md my-4' : 'w-full'}`}
        style={{
          backgroundColor: 'white',
          transform: `scale(${zoom / 100})`,
          transformOrigin: 'top center'
        }}
        onInput={(e) => onAnswer((e.target as HTMLDivElement).innerHTML)}
      />
    </div>
  );
}