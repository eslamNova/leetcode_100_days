import React from 'react';
import { CheckCircle2, XCircle } from 'lucide-react';

interface QuestionProps {
  number: number;
  text: string;
  isCorrect?: boolean;
  feedback?: string;
}

export function Question({ number, text, isCorrect, feedback }: QuestionProps) {
  return (
    <div className="mb-4 space-y-2">
      <div className="flex items-center gap-2">
        <h2 className="text-lg font-semibold">Question {number}</h2>
        {isCorrect !== undefined && (
          isCorrect ? (
            <CheckCircle2 className="w-5 h-5 text-green-500" />
          ) : (
            <XCircle className="w-5 h-5 text-red-500" />
          )
        )}
      </div>
      <p className="text-gray-700">{text}</p>
      {feedback && (
        <p className={`text-sm ${isCorrect ? 'text-green-600' : 'text-red-600'}`}>
          {feedback}
        </p>
      )}
    </div>
  );
}