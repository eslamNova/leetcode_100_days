import React from 'react';
import { Save, FileInput, Download, Printer } from 'lucide-react';
import { RibbonGroup } from './RibbonGroup';
import { RibbonButton } from './RibbonButton';

interface FileTabProps {
  onSave: () => void;
  onOpen: () => void;
  onExport: () => void;
  onPrint: () => void;
}

export function FileTab({ onSave, onOpen, onExport, onPrint }: FileTabProps) {
  return (
    <div className="flex gap-4 p-2">
      <RibbonGroup label="File Operations">
        <div className="flex gap-1">
          <RibbonButton
            icon={<Save className="w-4 h-4" />}
            label="Save"
            onClick={onSave}
          />
          <RibbonButton
            icon={<FileInput className="w-4 h-4" />}
            label="Open"
            onClick={onOpen}
          />
        </div>
        <div className="flex gap-1 mt-1">
          <RibbonButton
            icon={<Download className="w-4 h-4" />}
            label="Export"
            onClick={onExport}
          />
          <RibbonButton
            icon={<Printer className="w-4 h-4" />}
            label="Print"
            onClick={onPrint}
          />
        </div>
      </RibbonGroup>
    </div>
  );
}