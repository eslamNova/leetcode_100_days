import React from 'react';
import { Maximize2, Minimize2, Layout, Columns } from 'lucide-react';
import { RibbonGroup } from './RibbonGroup';
import { RibbonButton } from './RibbonButton';

interface ViewTabProps {
  onZoomIn: () => void;
  onZoomOut: () => void;
  onLayoutChange: (layout: string) => void;
}

export function ViewTab({ onZoomIn, onZoomOut, onLayoutChange }: ViewTabProps) {
  return (
    <div className="flex gap-4 p-2">
      <RibbonGroup label="Zoom">
        <div className="flex gap-1">
          <RibbonButton
            icon={<Maximize2 className="w-4 h-4" />}
            label="Zoom In"
            onClick={onZoomIn}
          />
          <RibbonButton
            icon={<Minimize2 className="w-4 h-4" />}
            label="Zoom Out"
            onClick={onZoomOut}
          />
        </div>
      </RibbonGroup>
      <RibbonGroup label="Document Views">
        <div className="flex gap-1">
          <RibbonButton
            icon={<Layout className="w-4 h-4" />}
            label="Print Layout"
            onClick={() => onLayoutChange('print')}
          />
          <RibbonButton
            icon={<Columns className="w-4 h-4" />}
            label="Web Layout"
            onClick={() => onLayoutChange('web')}
          />
        </div>
      </RibbonGroup>
    </div>
  );
}