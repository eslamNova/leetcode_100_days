import React from 'react';

interface RibbonButtonProps {
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
}

export function RibbonButton({ icon, label, onClick }: RibbonButtonProps) {
  return (
    <button
      onClick={onClick}
      className="flex flex-col items-center p-1 rounded hover:bg-gray-100 min-w-[48px]"
      title={label}
    >
      {icon}
      <span className="text-xs mt-1">{label}</span>
    </button>
  );
}