import React from 'react';
import { 
  Bold, Italic, Underline, AlignLeft, AlignCenter, 
  AlignRight, List, ListOrdered, Palette
} from 'lucide-react';
import { RibbonGroup } from './RibbonGroup';
import { RibbonButton } from './RibbonButton';

interface HomeTabProps {
  onFormatClick: (format: string) => void;
}

export function HomeTab({ onFormatClick }: HomeTabProps) {
  return (
    <div className="flex gap-4 p-2">
      <RibbonGroup label="Clipboard">
        <RibbonButton
          icon={<Palette className="w-4 h-4" />}
          label="Paste"
          onClick={() => document.execCommand('paste')}
        />
      </RibbonGroup>

      <RibbonGroup label="Font">
        <div className="flex gap-1">
          <RibbonButton
            icon={<Bold className="w-4 h-4" />}
            label="Bold"
            onClick={() => onFormatClick('bold')}
          />
          <RibbonButton
            icon={<Italic className="w-4 h-4" />}
            label="Italic"
            onClick={() => onFormatClick('italic')}
          />
          <RibbonButton
            icon={<Underline className="w-4 h-4" />}
            label="Underline"
            onClick={() => onFormatClick('underline')}
          />
        </div>
      </RibbonGroup>

      <RibbonGroup label="Paragraph">
        <div className="flex gap-1">
          <RibbonButton
            icon={<AlignLeft className="w-4 h-4" />}
            label="Left"
            onClick={() => onFormatClick('justifyLeft')}
          />
          <RibbonButton
            icon={<AlignCenter className="w-4 h-4" />}
            label="Center"
            onClick={() => onFormatClick('justifyCenter')}
          />
          <RibbonButton
            icon={<AlignRight className="w-4 h-4" />}
            label="Right"
            onClick={() => onFormatClick('justifyRight')}
          />
        </div>
        <div className="flex gap-1 mt-1">
          <RibbonButton
            icon={<List className="w-4 h-4" />}
            label="Bullet List"
            onClick={() => onFormatClick('insertUnorderedList')}
          />
          <RibbonButton
            icon={<ListOrdered className="w-4 h-4" />}
            label="Number List"
            onClick={() => onFormatClick('insertOrderedList')}
          />
        </div>
      </RibbonGroup>
    </div>
  );
}