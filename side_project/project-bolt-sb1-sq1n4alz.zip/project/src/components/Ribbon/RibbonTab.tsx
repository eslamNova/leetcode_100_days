import React from 'react';

interface RibbonTabProps {
  label: string;
  isActive: boolean;
  onClick: () => void;
}

export function RibbonTab({ label, isActive, onClick }: RibbonTabProps) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 text-sm font-medium transition-colors
        ${isActive 
          ? 'bg-white text-blue-600 border-t-2 border-blue-600' 
          : 'text-gray-600 hover:bg-gray-100'
        }`}
    >
      {label}
    </button>
  );
}