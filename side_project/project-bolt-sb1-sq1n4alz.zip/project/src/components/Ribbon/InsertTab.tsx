import React from 'react';
import { Image, Link } from 'lucide-react';
import { RibbonGroup } from './RibbonGroup';
import { RibbonButton } from './RibbonButton';
import { TableInsert } from '../Editor/TableInsert';

interface InsertTabProps {
  onInsertImage: () => void;
  onInsertTable: (rows: number, cols: number) => void;
  onInsertLink: () => void;
}

export function InsertTab({ onInsertImage, onInsertTable, onInsertLink }: InsertTabProps) {
  return (
    <div className="flex gap-4 p-2">
      <RibbonGroup label="Illustrations">
        <RibbonButton
          icon={<Image className="w-4 h-4" />}
          label="Picture"
          onClick={onInsertImage}
        />
      </RibbonGroup>

      <RibbonGroup label="Tables">
        <TableInsert onInsert={onInsertTable} />
      </RibbonGroup>

      <RibbonGroup label="Links">
        <RibbonButton
          icon={<Link className="w-4 h-4" />}
          label="Link"
          onClick={onInsertLink}
        />
      </RibbonGroup>
    </div>
  );
}