import React from 'react';
import { AlignJustify, ArrowDownWideNarrow, IndentIcon, OutdentIcon } from 'lucide-react';
import { RibbonGroup } from './RibbonGroup';
import { RibbonButton } from './RibbonButton';

interface LayoutTabProps {
  onFormat: (command: string) => void;
}

export function LayoutTab({ onFormat }: LayoutTabProps) {
  return (
    <div className="flex gap-4 p-2">
      <RibbonGroup label="Paragraph">
        <div className="flex gap-1">
          <RibbonButton
            icon={<AlignJustify className="w-4 h-4" />}
            label="Justify"
            onClick={() => onFormat('justifyFull')}
          />
          <RibbonButton
            icon={<ArrowDownWideNarrow className="w-4 h-4" />}
            label="Line Spacing"
            onClick={() => onFormat('lineHeight')}
          />
        </div>
        <div className="flex gap-1 mt-1">
          <RibbonButton
            icon={<IndentIcon className="w-4 h-4" />}
            label="Indent"
            onClick={() => onFormat('indent')}
          />
          <RibbonButton
            icon={<OutdentIcon className="w-4 h-4" />}
            label="Outdent"
            onClick={() => onFormat('outdent')}
          />
        </div>
      </RibbonGroup>
    </div>
  );
}