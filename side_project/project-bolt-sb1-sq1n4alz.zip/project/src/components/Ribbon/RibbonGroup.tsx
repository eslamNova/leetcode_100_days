import React from 'react';

interface RibbonGroupProps {
  label: string;
  children: React.ReactNode;
}

export function RibbonGroup({ label, children }: RibbonGroupProps) {
  return (
    <div className="flex flex-col items-center border-r border-gray-200 pr-4">
      <div className="mb-1">{children}</div>
      <span className="text-xs text-gray-600">{label}</span>
    </div>
  );
}