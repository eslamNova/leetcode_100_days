import React, { useState } from 'react';
import { Save, Image } from 'lucide-react';

interface EditorProps {
  question: string;
  onAnswer: (answer: string) => void;
}

export function Editor({ question, onAnswer }: EditorProps) {
  const [content, setContent] = useState('');

  const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setContent(e.target.value);
    onAnswer(e.target.value);
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-4">
      <div className="border-b border-gray-200 pb-2 mb-4">
        <div className="flex gap-4">
          <button
            className="flex items-center gap-2 px-3 py-1 text-sm rounded hover:bg-gray-100"
            title="Save (Ctrl+S)"
          >
            <Save className="w-4 h-4" />
            Save
          </button>
          <button
            className="flex items-center gap-2 px-3 py-1 text-sm rounded hover:bg-gray-100"
            title="Insert Image"
          >
            <Image className="w-4 h-4" />
            Insert Image
          </button>
        </div>
      </div>
      <textarea
        className="w-full h-[500px] p-4 border border-gray-200 rounded resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
        value={content}
        onChange={handleContentChange}
        placeholder="Start typing your answer here..."
      />
    </div>
  );
}