import React, { useState } from 'react';
import { ExcelRibbon } from './ExcelRibbon';
import { SpreadsheetGrid } from './SpreadsheetGrid';

interface ExcelEditorProps {
  initialData?: string[][];
  onAnswer: (data: string[][]) => void;
}

export function ExcelEditor({ initialData, onAnswer }: ExcelEditorProps) {
  const [activeCell, setActiveCell] = useState<{ row: number; col: number } | null>(null);
  const [data, setData] = useState<string[][]>(initialData || [
    Array(26).fill(""),
    Array(26).fill(""),
    Array(26).fill(""),
    Array(26).fill(""),
    Array(26).fill(""),
    Array(26).fill(""),
    Array(26).fill(""),
    Array(26).fill(""),
    Array(26).fill(""),
    Array(26).fill(""),
    Array(26).fill(""),
    Array(26).fill(""),
    Array(26).fill(""),
    Array(26).fill(""),
    Array(26).fill(""),
  ]);

  const handleCellChange = (row: number, col: number, value: string) => {
    const newData = data.map((r, i) =>
      i === row ? r.map((c, j) => j === col ? value : c) : r
    );
    setData(newData);
    onAnswer(newData);
  };

  return (
    <div className="bg-white rounded-lg shadow-lg">
      <ExcelRibbon
        onFormat={(format) => {
          if (activeCell) {
            // Handle cell formatting
          }
        }}
      />
      <div className="p-1">
        <SpreadsheetGrid
          data={data}
          activeCell={activeCell}
          onCellSelect={setActiveCell}
          onCellChange={handleCellChange}
        />
      </div>
    </div>
  );
}