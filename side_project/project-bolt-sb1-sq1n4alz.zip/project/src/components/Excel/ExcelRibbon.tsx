import React from 'react';
import { RibbonGroup } from '../Ribbon/RibbonGroup';
import { RibbonButton } from '../Ribbon/RibbonButton';
import { Bold, Italic, DollarSign, Percent, AlignLeft, AlignCenter, AlignRight } from 'lucide-react';

interface ExcelRibbonProps {
  onFormat: (format: string) => void;
}

export function ExcelRibbon({ onFormat }: ExcelRibbonProps) {
  return (
    <div className="border-b border-gray-200">
      <div className="flex gap-4 p-2">
        <RibbonGroup label="Font">
          <div className="flex gap-1">
            <RibbonButton
              icon={<Bold className="w-4 h-4" />}
              label="Bold"
              onClick={() => onFormat('bold')}
            />
            <RibbonButton
              icon={<Italic className="w-4 h-4" />}
              label="Italic"
              onClick={() => onFormat('italic')}
            />
          </div>
        </RibbonGroup>

        <RibbonGroup label="Number">
          <div className="flex gap-1">
            <RibbonButton
              icon={<DollarSign className="w-4 h-4" />}
              label="Currency"
              onClick={() => onFormat('currency')}
            />
            <RibbonButton
              icon={<Percent className="w-4 h-4" />}
              label="Percent"
              onClick={() => onFormat('percent')}
            />
          </div>
        </RibbonGroup>

        <RibbonGroup label="Alignment">
          <div className="flex gap-1">
            <RibbonButton
              icon={<AlignLeft className="w-4 h-4" />}
              label="Left"
              onClick={() => onFormat('alignLeft')}
            />
            <RibbonButton
              icon={<AlignCenter className="w-4 h-4" />}
              label="Center"
              onClick={() => onFormat('alignCenter')}
            />
            <RibbonButton
              icon={<AlignRight className="w-4 h-4" />}
              label="Right"
              onClick={() => onFormat('alignRight')}
            />
          </div>
        </RibbonGroup>
      </div>
    </div>
  );
}