import React, { useState } from 'react';

interface SpreadsheetGridProps {
  data: string[][];
  activeCell: { row: number; col: number } | null;
  onCellSelect: (cell: { row: number; col: number } | null) => void;
  onCellChange: (row: number, col: number, value: string) => void;
}

export function SpreadsheetGrid({
  data,
  activeCell,
  onCellSelect,
  onCellChange
}: SpreadsheetGridProps) {
  const cols = Array.from({ length: 26 }, (_, i) => 
    String.fromCharCode(65 + i)
  );

  // Track column widths
  const [columnWidths, setColumnWidths] = useState<Record<number, number>>(
    Object.fromEntries(cols.map((_, i) => [i, 120]))
  );

  const handleColumnResize = (colIndex: number, width: number) => {
    setColumnWidths(prev => ({
      ...prev,
      [colIndex]: Math.max(60, width)
    }));
  };

  return (
    <div className="overflow-auto border border-gray-300 rounded-lg bg-white">
      <table className="border-collapse w-full table-fixed">
        <colgroup>
          <col style={{ width: '40px' }} />
          {cols.map((_, index) => (
            <col key={index} style={{ width: `${columnWidths[index]}px` }} />
          ))}
        </colgroup>
        <thead>
          <tr className="bg-gray-50">
            <th className="sticky left-0 z-20 bg-gray-50 border-b border-r border-gray-300 h-8"></th>
            {cols.map((col, index) => (
              <th
                key={col}
                className="relative border-b border-r border-gray-300 h-8 select-none"
              >
                <div className="flex items-center justify-center text-sm font-semibold text-gray-600">
                  {col}
                </div>
                <div
                  className="absolute top-0 right-0 h-full w-1 cursor-col-resize hover:bg-blue-400"
                  onMouseDown={(e) => {
                    const startX = e.pageX;
                    const startWidth = columnWidths[index];
                    
                    const handleMouseMove = (e: MouseEvent) => {
                      const diff = e.pageX - startX;
                      handleColumnResize(index, startWidth + diff);
                    };
                    
                    const handleMouseUp = () => {
                      document.removeEventListener('mousemove', handleMouseMove);
                      document.removeEventListener('mouseup', handleMouseUp);
                    };
                    
                    document.addEventListener('mousemove', handleMouseMove);
                    document.addEventListener('mouseup', handleMouseUp);
                  }}
                />
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((row, rowIndex) => (
            <tr key={rowIndex} className="hover:bg-gray-50">
              <td className="sticky left-0 z-10 bg-gray-50 border-r border-b border-gray-300 text-sm text-center text-gray-600 font-medium">
                {rowIndex + 1}
              </td>
              {row.map((cell, colIndex) => (
                <td
                  key={`${rowIndex}-${colIndex}`}
                  className={`relative border-r border-b border-gray-300 p-0 ${
                    activeCell?.row === rowIndex && activeCell?.col === colIndex
                      ? 'z-10'
                      : ''
                  }`}
                  onClick={() => onCellSelect({ row: rowIndex, col: colIndex })}
                >
                  <div className="relative">
                    {activeCell?.row === rowIndex && activeCell?.col === colIndex ? (
                      <div className="absolute -inset-[1px] border-2 border-blue-500 pointer-events-none" />
                    ) : null}
                    <input
                      type="text"
                      value={cell}
                      onChange={(e) => onCellChange(rowIndex, colIndex, e.target.value)}
                      className="w-full h-7 px-2 border-none focus:outline-none bg-transparent"
                    />
                  </div>
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}