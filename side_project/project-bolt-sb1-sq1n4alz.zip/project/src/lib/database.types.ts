export interface Database {
  public: {
    Tables: {
      user_profiles: {
        Row: {
          id: string;
          full_name: string;
          email: string;
          created_at: string;
        };
        Insert: {
          id: string;
          full_name: string;
          email: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          full_name?: string;
          email?: string;
          created_at?: string;
        };
      };
      exam_results: {
        Row: {
          id: string;
          user_id: string;
          exam_type: 'word' | 'excel';
          score: number;
          answers: Record<string, any>;
          completed_at: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          exam_type: 'word' | 'excel';
          score: number;
          answers: Record<string, any>;
          completed_at?: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          exam_type?: 'word' | 'excel';
          score?: number;
          answers?: Record<string, any>;
          completed_at?: string;
          created_at?: string;
        };
      };
    };
  };
}