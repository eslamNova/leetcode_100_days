import { supabase } from './supabase';

export async function createTestUser() {
  const email = 'test@example.com';
  const password = 'test123456';
  const fullName = 'Test User';

  try {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: { full_name: fullName }
      }
    });

    if (error) throw error;

    if (data.user) {
      await supabase
        .from('user_profiles')
        .insert([{ 
          id: data.user.id,
          email,
          full_name: fullName
        }]);
    }

    return { email, password };
  } catch (error) {
    console.error('Error creating test user:', error);
    throw error;
  }
}