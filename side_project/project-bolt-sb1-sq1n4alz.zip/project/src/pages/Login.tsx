import React from 'react';
import { Link } from 'react-router-dom';
import { FileText } from 'lucide-react';
import { useAuth } from '../components/auth/AuthProvider';
import { FormInput } from '../components/ui/FormInput';
import { LoadingSpinner } from '../components/ui/LoadingSpinner';
import { ErrorMessage } from '../components/ui/ErrorMessage';
import { useAuthForm } from '../hooks/useAuthForm';

export function Login() {
  const { signIn } = useAuth();
  const { values, errors, loading, handleChange, handleSubmit } = useAuthForm({
    onSubmit: async (values) => {
      await signIn(values.email, values.password);
    }
  });

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center">
      <div className="bg-white p-8 rounded-lg shadow-md w-96">
        <div className="flex items-center justify-center mb-6">
          <FileText className="w-10 h-10 text-blue-600" />
          <h1 className="text-2xl font-bold ml-2">Sign In</h1>
        </div>

        {errors.form && (
          <ErrorMessage message={errors.form} />
        )}

        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <FormInput
            label="Email"
            name="email"
            type="email"
            value={values.email || ''}
            onChange={handleChange}
            error={errors.email}
            required
            disabled={loading}
          />

          <FormInput
            label="Password"
            name="password"
            type="password"
            value={values.password || ''}
            onChange={handleChange}
            error={errors.password}
            required
            disabled={loading}
          />

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
          >
            {loading ? <LoadingSpinner /> : 'Sign In'}
          </button>
        </form>

        <p className="mt-4 text-center text-sm text-gray-600">
          Don't have an account?{' '}
          <Link to="/register" className="text-blue-600 hover:text-blue-500">
            Register
          </Link>
        </p>
      </div>
    </div>
  );
}