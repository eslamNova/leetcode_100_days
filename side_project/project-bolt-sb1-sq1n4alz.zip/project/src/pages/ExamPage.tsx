import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { WordEditor } from '../components/Editor/WordEditor';
import { ExcelEditor } from '../components/Excel/ExcelEditor';
import { Question } from '../components/Question';
import { questions } from '../data/questions';
import { excelQuestions } from '../data/excelQuestions';

export function ExamPage() {
  const { type } = useParams<{ type: string }>();
  const navigate = useNavigate();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<number, any>>({});

  const questionList = type === 'excel' ? excelQuestions : questions;
  const currentQ = questionList[currentQuestion];

  const handleAnswer = (answer: any) => {
    setAnswers(prev => ({
      ...prev,
      [currentQ.id]: answer
    }));
  };

  const handleFinish = () => {
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gray-100 py-8">
      <div className="max-w-7xl mx-auto px-4">
        <Question
          number={currentQuestion + 1}
          text={currentQ.text}
        />

        <div className="mt-4">
          {type === 'excel' ? (
            <ExcelEditor
              initialData={currentQ.initialData}
              onAnswer={handleAnswer}
            />
          ) : (
            <WordEditor onAnswer={handleAnswer} />
          )}
        </div>

        <div className="mt-6 flex justify-between">
          <button
            onClick={() => setCurrentQuestion(prev => Math.max(0, prev - 1))}
            disabled={currentQuestion === 0}
            className="px-4 py-2 bg-gray-600 text-white rounded disabled:opacity-50"
          >
            Previous
          </button>

          {currentQuestion === questionList.length - 1 ? (
            <button
              onClick={handleFinish}
              className="px-4 py-2 bg-green-600 text-white rounded"
            >
              Finish Exam
            </button>
          ) : (
            <button
              onClick={() => setCurrentQuestion(prev => Math.min(questionList.length - 1, prev + 1))}
              className="px-4 py-2 bg-blue-600 text-white rounded"
            >
              Next
            </button>
          )}
        </div>
      </div>
    </div>
  );
}