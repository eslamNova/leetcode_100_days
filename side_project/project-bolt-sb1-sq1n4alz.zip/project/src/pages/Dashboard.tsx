import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FileText, Table2 } from 'lucide-react';

export function Dashboard() {
  const navigate = useNavigate();

  const handleStartExam = (type: 'word' | 'excel') => {
    navigate(`/exam/${type}`);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center">
            <FileText className="w-8 h-8 text-blue-600" />
            <h1 className="ml-2 text-2xl font-bold text-gray-900">Office Skills Assessment</h1>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Start New Assessment</h2>
          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => handleStartExam('word')}
              className="flex flex-col items-center justify-center p-4 border-2 border-blue-200 rounded-lg hover:border-blue-500 transition-colors"
            >
              <FileText className="w-8 h-8 text-blue-600 mb-2" />
              <span>Word Skills</span>
            </button>
            <button
              onClick={() => handleStartExam('excel')}
              className="flex flex-col items-center justify-center p-4 border-2 border-green-200 rounded-lg hover:border-green-500 transition-colors"
            >
              <Table2 className="w-8 h-8 text-green-600 mb-2" />
              <span>Excel Skills</span>
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}