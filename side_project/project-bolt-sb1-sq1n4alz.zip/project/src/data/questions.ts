export interface Question {
  id: number;
  text: string;
  requiredFeatures: string[];
  hints: string[];
  evaluation: (content: string) => boolean;
}

export const questions: Question[] = [
  {
    id: 1,
    text: "Create a document with a title in bold and centered, then save it. Describe the steps you took.",
    requiredFeatures: ["bold", "center", "save"],
    hints: ["Use the Home tab for text formatting", "Look for the Save button in the File tab"],
    evaluation: (content) => content.includes('bold') && content.includes('center')
  },
  {
    id: 2,
    text: "Insert an image and align it to the center of the document. Add a caption below the image.",
    requiredFeatures: ["image", "center"],
    hints: ["Use the Insert tab to add an image", "Center alignment is in the Home tab"],
    evaluation: (content) => content.includes('img') && content.includes('text-align: center')
  },
  {
    id: 3,
    text: "Create a table with 3 columns and 3 rows. Add headers in bold and center-align all cells.",
    requiredFeatures: ["table", "bold", "center"],
    hints: ["Insert tab for table", "Home tab for text formatting"],
    evaluation: (content) => content.includes('table') && content.includes('bold')
  },
  {
    id: 4,
    text: "Create a numbered list of three items, then convert it to a bulleted list.",
    requiredFeatures: ["numbered list", "bulleted list"],
    hints: ["Find list options in the Home tab"],
    evaluation: (content) => content.includes('ul') || content.includes('ol')
  },
  {
    id: 5,
    text: "Write a paragraph and justify the text. Then change the line spacing to 2.0.",
    requiredFeatures: ["justify", "line spacing"],
    hints: ["Look in the Layout tab for paragraph formatting"],
    evaluation: (content) => content.includes('justify') || content.includes('line-height')
  },
  {
    id: 6,
    text: "Insert a hyperlink to www.example.com and format it in italic.",
    requiredFeatures: ["link", "italic"],
    hints: ["Insert tab for links", "Home tab for italic formatting"],
    evaluation: (content) => content.includes('href') && content.includes('italic')
  },
  {
    id: 7,
    text: "Create a document with different zoom levels and switch between Print and Web layouts.",
    requiredFeatures: ["zoom", "layout"],
    hints: ["Use the View tab to change zoom and layout"],
    evaluation: (content) => true // Visual verification needed
  },
  {
    id: 8,
    text: "Write a paragraph and use the indent feature to create a block quote effect.",
    requiredFeatures: ["indent"],
    hints: ["Find indent options in the Layout tab"],
    evaluation: (content) => content.includes('margin-left') || content.includes('text-indent')
  },
  {
    id: 9,
    text: "Create a document with multiple paragraphs and export it as a PDF.",
    requiredFeatures: ["export"],
    hints: ["Look for Export in the File tab"],
    evaluation: (content) => content.length > 100 // Basic length check
  },
  {
    id: 10,
    text: "Format a paragraph with different font styles, then print the document.",
    requiredFeatures: ["font", "print"],
    hints: ["Use Home tab for fonts", "Find Print in File tab"],
    evaluation: (content) => content.includes('font-family') || content.includes('style')
  }
];