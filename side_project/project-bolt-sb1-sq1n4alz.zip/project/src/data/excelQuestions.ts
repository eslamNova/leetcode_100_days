export interface ExcelQuestion {
  id: number;
  text: string;
  initialData?: string[][];
  solution?: string[][];
  requiredFeatures: string[];
  evaluation: (data: string[][]) => { correct: boolean; feedback: string };
}

export const excelQuestions: ExcelQuestion[] = [
  {
    id: 1,
    text: "Create a simple budget spreadsheet with the following columns: Category, Budget, Actual, Difference. Add at least 3 expense categories and calculate the differences using formulas.",
    initialData: [
      ["Category", "Budget", "Actual", "Difference"],
      ["", "", "", ""]
    ],
    requiredFeatures: ["formulas", "cell-formatting"],
    evaluation: (data) => {
      const hasHeaders = data[0]?.includes("Category") && 
                        data[0]?.includes("Budget") && 
                        data[0]?.includes("Actual") && 
                        data[0]?.includes("Difference");
      const hasThreeRows = data.length >= 4; // Header + 3 entries
      const hasFormulas = data.some(row => row[3]?.startsWith("="));
      
      return {
        correct: hasHeaders && hasThreeRows && hasFormulas,
        feedback: hasHeaders && hasThreeRows && hasFormulas
          ? "Perfect! You've created a proper budget spreadsheet with formulas."
          : `Missing: ${!hasHeaders ? 'correct headers' : ''} 
             ${!hasThreeRows ? 'three expense categories' : ''} 
             ${!hasFormulas ? 'formulas for differences' : ''}`
      };
    }
  }
];