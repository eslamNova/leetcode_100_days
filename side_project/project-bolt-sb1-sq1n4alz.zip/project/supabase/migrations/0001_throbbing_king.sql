/*
  # Exam System Schema

  1. New Tables
    - exam_results
      - id (uuid, primary key)
      - user_id (references auth.users)
      - exam_type (text: 'word' or 'excel')
      - score (integer)
      - answers (jsonb)
      - completed_at (timestamp)
    - user_profiles
      - id (uuid, primary key, references auth.users)
      - full_name (text)
      - email (text)
      - created_at (timestamp)

  2. Security
    - Enable RLS on all tables
    - Users can only read/write their own data
*/

-- Create user profiles table
CREATE TABLE user_profiles (
  id uuid PRIMARY KEY REFERENCES auth.users,
  full_name text,
  email text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile"
  ON user_profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON user_profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Create exam results table
CREATE TABLE exam_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  exam_type text NOT NULL CHECK (exam_type IN ('word', 'excel')),
  score integer NOT NULL,
  answers jsonb NOT NULL,
  completed_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE exam_results ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own exam results"
  ON exam_results FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own exam results"
  ON exam_results FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);